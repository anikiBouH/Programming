
public class Methods {

	public static void sumArray(int[] ar) 
	{
		int res = 0;
		for (int i : ar) {
			res += i;
			System.out.println(res);
		}
	}
}
