
public class coordinates {
    public int x;
    public int y;

    public coordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
