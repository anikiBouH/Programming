package lesson17;

public class HomeWork {

	public static void main(String[] args) {
		
		System.out.println(MyMethods.XpowerY(2, 5));
		
		int[] ar = {9,2,1,4,5};
		MyMethods.printArrayReverse(ar);
		
		System.out.println(MyMethods.arrayEvensSum(ar));
		
	}

}
